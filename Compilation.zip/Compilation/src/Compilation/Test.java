package Compilation;

import java.util.Arrays;
import java.util.List;

public class Test {

	public static void main(String[] args) {

		List<String> Test=Arrays.asList("cdcbc","bcdcbcb","cbdcbdcbc",
				"ccdcbcdcbcdcbbcr","cdcbbb","cdcb");
		
		for(String Case: Test) {
			ClassParseur Ps= new ClassParseur(Case);
			
			System.out.println("Reasultat :"+ Case + (Ps.parse()?
					"Is Accepted !": "Is Refuse !!!!! "));
		}
		
	}

}
