package Compilation;

public class ClassParseur {
  private String Str;
  private int indice;
  
  
  public ClassParseur(String str){
	  this.Str=str;
	  this.indice=0;
	  
  }
  
   public boolean S() {
	   int Star=indice;
	   
	   if (match('b')) {
		   if ( S()&& match('b')) {
			   return true;
		   }
		   indice=Star;
	   }
	   if (match('c')) {
		   if ( A()&& match('c')) {
			   return true;
		   }
		   indice=Star;
		   
	   }	return false;
   }
   
   public boolean A() {
	   int Star=indice;
   
	   if(match('b')) {
		   
		   
		 if ( A() && A()) {
			   return true;
	     }
		 
		   indice=Star;
		   
		   
		if(match('c')) {
			if(A() && S() && match('A') && match('b')) {
				return true;
			}
		indice=Star;
		}
		}
	   if(match('d')&& match('c')&& match('b')) {
		   return true;
	   }
	   return false;
   }
   
   
  private boolean match(char C) {
	  if(indice<Str.length() && Str.charAt(indice) == C) {
		  indice++;
		  return true;
	  }
	  
	return false;
}

public boolean parse() {
	  return S() && indice == Str.length();
	  
  }
  
	
}
